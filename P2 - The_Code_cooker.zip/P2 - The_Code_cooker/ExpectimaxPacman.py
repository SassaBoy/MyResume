import numpy as np


'''
In this algorithm, Pacman is considered the "maximizer" agent, and the ghosts are considered the "expectimizer" agents. 
The algorithm works by first evaluating the current position of Pacman and the ghosts. If Pacman is at the fruit position, then the algorithm returns 1.
If Pacman is at a ghost position, then the algorithm returns -1. 
If Pacman is not at the fruit or a ghost position, the algorithm evaluates all possible moves for Pacman and the ghosts. 
For each move, the algorithm calculates the expectimax score, which is the average of the expectimax scores for the ghost positions, plus the expectimax score for the Pacman position. 
Finally, the algorithm returns the maximum score of all the possible moves.

'''

# define the game board as an array
game_matrix = np.array([
             [0, 0, 0, 0, 0],
             [0, 1, 0, 0, 0],
             [0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0]])
 
# define the initial positions of Pacman, ghosts, and the fruit
pacmanLocatedAt = (1, 0)
ghostsLocatedAt = [(2, 0), (2, 1)]
fruitsLocatedAt = (4, 4)
 
# define the set of legal moves. This are the moves that pacman can take
possibleMoves = {(0, -1), (0, 1), (-1, 0), (1, 0)}
 
# define a function to check if a move is valid
def is_valid_move(game_matrix, loc, move):
    new_loc = (loc[0] + move[0], loc[1] + move[1])
    # check if the proposed move is within the bounds of the board
    if new_loc[0] < 0 or new_loc[1] < 0 or new_loc[0] >= game_matrix.shape[0] or new_loc[1] >= game_matrix.shape[1]:
        return False

    # check if the new position is a wall or not
    #This is because the wall is an edge that pacman cannot go through
    if game_matrix[new_loc[0], new_loc[1]] == 0:
        return False
    return True
 
# define the expectimax algorithm to calculate our best move for pacman
def expectimax(game_matrix, loc, ghostsLocatedAt, fruit_loc, max_depth=50):
    # base case: if Pacman is at the fruit position
    if loc == fruit_loc or max_depth == 0:
        return 1
    # base case: if Pacman is at a ghost position
    for ghostsLocated in ghostsLocatedAt:
        if loc == ghostsLocated:
            return -1
    # if Pacman is not at the fruit or a ghost position
    #Here we are returning inf meaning that the algorithm was unable to find the best move for pacman
    maximumScore = -float('inf')
    for move in possibleMoves:
        # check if the move is valid
        if is_valid_move(game_matrix, loc, move):
            # calculate the expectimax score of the new position
            new_loc = (loc[0] + move[0], loc[1] + move[1])
            expectimax_score = 0
            for ghost_loc in ghostsLocatedAt:
                # calculate the expectimax score of the ghost position
                ghost_score = expectimax(game_matrix, ghost_loc, ghostsLocatedAt, fruit_loc, max_depth-1)
                expectimax_score += ghost_score / len(ghostsLocatedAt)
            # calculate the expectimax score of the Pacman position
            pacman_score = expectimax(game_matrix, new_loc, ghostsLocatedAt, fruit_loc, max_depth-1)
            expectimax_score += pacman_score
            # update the max score if necessary
            maximumScore = max(maximumScore, expectimax_score)
    return maximumScore
 
# call the expectimax algorithm
pacManScore = expectimax(game_matrix, pacmanLocatedAt, ghostsLocatedAt, fruitsLocatedAt)
print(pacManScore)