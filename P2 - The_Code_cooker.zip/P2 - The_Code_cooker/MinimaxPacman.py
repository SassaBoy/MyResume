
#This is an adveserial algorithm called the minimax algorithm
'''
Depth refers to how many levels of the game tree should be explored. 
As the depth increases, the algorithm will explore more potential moves, making the algorithm more accurate in predicting the best move.
'''
def pacman_minimax(state, depth):
  if state.is_terminal() or depth == 0:
    return state.utility()
  
  '''
  efers to the best possible score that can be achieved for the current state. 
  If the current state is a maximizer (i.e. Pacman's turn),
  then best value is the maximum score that can be achieved. 
  If the current state is a minimizer (i.e. ghost's turn), then best value is the minimum score that can be achieved.
  '''
  

  if state.turn == 'pacman':
    best_value = float('-inf')
    for action in state.actions():
     # If self.turn = 'pacman', then it is Pacman's turn and the minimax algorithm should maximize the score.
     ''' Here calculates the best value by taking the maximum of the current best value and the result of the pacman_minimax algorithm for the next state. 
     The algorithm recursively calls itself on the next state, with a decreased depth, until it reaches the end of the game tree or the desired depth.
     '''
    best_value = max(best_value, pacman_minimax(state.result(action), depth-1))
    return best_value

  else:
    best_value = float('inf')
    for action in state.actions():
       # If self.turn = 'ghost', then it is the ghost's turn and the minimax algorithm should minimize the score.
      best_value = min(best_value, pacman_minimax(state.result(action), depth-1))
    return best_value



'''
The evaluation function is used to evaluate the score of a given game state. It takes into account the distance between Pacman
and food and the distance between Pacman and the ghosts. 
The evaluation function returns a score which is then used by the minimax algorithm to predict the best move.
'''
def evaluation(state):
  score = 0
  pacman_loc = state.pacman_location
  food_locs = state.food_locations
  ghost_locs = state.ghost_locations
  
  # calculate score based on distance to food
  #if the Pacman is close to some food, the output score from the evaluation function would be positive. If the Pacman is close to some ghosts, the output score would be negative.
  for food in food_locs:
    score += (1 / (abs(pacman_loc[0] - food[0]) + abs(pacman_loc[1] - food[1])))
    
  # subtract score based on distance to ghosts 
  for ghost in ghost_locs:
    score -= (1 / (abs(pacman_loc[0] - ghost[0]) + abs(pacman_loc[1] - ghost[1])))
  
  return score



