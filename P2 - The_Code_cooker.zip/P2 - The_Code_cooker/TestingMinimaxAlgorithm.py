
from MinimaxPacman import evaluation, pacman_minimax

#The output of the algorithm would depend on the state of the game. For example, if the Pacman is close to some food, the output score from the evaluation function would be positive. If the Pacman is close to some ghosts, the output score would be negative.


#PacmanState('start') is a representation of the initial state of a Pacman game. This includes information such as the locations of Pacman, food, and ghosts.

import random
#Create the pacman game environment

class PacmanGame:
  def __init__(self):
    #the width of the environment
    self.width = 10
    #The height of the environment
    self.height = 10
    #Where pacman is currently at is a random number between 0 and 7.
    #It cannot be 8 because that means that pacman is on the edge of the game
    self.pacman_location = (random.randint(0, self.width - 1), random.randint(0, self.height - 1))
    self.food_locations = [(random.randint(0, self.width - 1), random.randint(0, self.height - 1)) for _ in range(5)]
    self.ghost_locations = [(random.randint(0, self.width - 1), random.randint(0, self.height - 1)) for _ in range(3)]
    self.turn = 'pacman'
  
  #The utility or payoff functions calls the evaluation function to determine the payoffs
  def utility(self):
    return evaluation(self)
  
  #To check if the node is a terminal node or not. A terminal state is a state where the game has ended, either in a win or a loss.
  #The method checks if the number of food locations is 0. If it is, then the game has ended and the state is terminal.
  def is_terminal(self):
    return len(self.food_locations) == 0
  
  def actions(self):
    if self.turn == 'pacman':
      #(0,1) represents a movement up, (0,-1) represents a movement down, (1,0) represents a movement right, and (-1,0) represents a movement left.
      actions = [(0, 1), (0, -1), (1, 0), (-1, 0)]      
      valid_actions = []
      for action in actions:
        '''
        The current location of Pacman is stored in the self.pacman_location variable, which is a tuple of the form (x,y). 
        The next_location variable is calculated by adding the action tuple to the self.pacman_location tuple.
        '''
        next_location = (self.pacman_location[0] + action[0], self.pacman_location[1] + action[1])
        if (next_location[0] >= 0 and next_location[0] < self.width and
            next_location[1] >= 0 and next_location[1] < self.height):
          valid_actions.append(action)
      return valid_actions
    else:
      return []
  
  #This is the ghost's turn to play
  def result(self, action):
    new_state = PacmanGame()
    new_state.width = self.width
    new_state.height = self.height
    new_state.pacman_location = (self.pacman_location[0] + action[0], self.pacman_location[1] + action[1])
    new_state.food_locations = self.food_locations[:]
    new_state.ghost_locations = self.ghost_locations[:]
    new_state.turn = 'ghost'
#if the new Pacman location is in the list of food locations, then the food is removed from the list.
    if new_state.pacman_location in new_state.food_locations:
      new_state.food_locations.remove(new_state.pacman_location)
    return new_state

game = PacmanGame()
score = pacman_minimax(game, 5)
print(score)


# By changing the evaluation function, we can optimize the minimax algorithm for different playing strategies.
def secondEvaluationFunction(state):
  score = 0
  pacman_loc = state.pacman_location
  food_locs = state.food_locations
  ghost_locs = state.ghost_locations
  
  # add score based on distance to food
  for food in food_locs:
    score += (abs(pacman_loc[0] - food[0]) + abs(pacman_loc[1] - food[1]))
    
  # subtract score based on distance to ghosts 
  for ghost in ghost_locs:
    score -= (abs(pacman_loc[0] - ghost[0]) + abs(pacman_loc[1] - ghost[1]))
  
  return score

game = PacmanGame()
score = pacman_minimax(game, 5)
print(score)

