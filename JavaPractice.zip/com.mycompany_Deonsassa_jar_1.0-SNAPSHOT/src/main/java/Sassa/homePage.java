
package Sassa;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import static java.awt.Color.white;
import java.awt.event.*;

public class homePage extends JFrame implements ActionListener{

    private final JPanel contentPane;
    private final JButton b1;
    private final JButton b2;
    private final JButton b3;
    private final JButton b4;
  

    public static void main(String[] args) {
        new homePage().setVisible(true);
    }

    public homePage() {
        super("Deon");
        setBounds(400, 150, 1000, 800);
        contentPane = new JPanel();
        setContentPane(contentPane);
        contentPane.setLayout(null);


        JMenuBar menuBar = new JMenuBar();
        menuBar.add(Box.createRigidArea(new Dimension(400,100)));
        menuBar.setBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(0, 128, 0), new Color(128, 128, 128)));
        menuBar.setBackground(Color.BLACK);
        menuBar.setBounds(0, 10, 1000, 40);
        contentPane.add(menuBar);




        JLabel l1 = new JLabel("Welcome To The Nust Library Page ");
        l1.setForeground(new Color(204, 51, 102));
        l1.setFont(new Font("Segoe UI Semilight", Font.BOLD, 30));
        l1.setBounds(268, 30, 701, 80);
        contentPane.add(l1);
        //204, 51, 102

        JLabel l3 = new JLabel("");
        l3.setBounds(300, 160, 134, 128);
        contentPane.add(l3);

        JLabel l4 = new JLabel("");
        l4.setBounds(530, 140, 225, 152);
        contentPane.add(l4);

        b1 = new JButton("Add Book");
        b1.addActionListener(this);
        b1.setBackground(Color.BLACK);
        b1.setForeground(Color.white);
        b1.setBounds(60, 320, 159, 44);
        contentPane.add(b1);

        b2 = new JButton("New User");
        b2.addActionListener(this);
        b2.setBackground(Color.BLACK);
        b2.setForeground(Color.white);
        b2.setBounds(562, 320, 167, 44);
        contentPane.add(b2);

        JPanel panel = new JPanel();
        panel.setBorder(new TitledBorder(new LineBorder(new Color(250, 128, 114), 2),"", TitledBorder.LEADING,
        TitledBorder.TOP, null, new Color(100, 100, 100)));
        panel.setBounds(20, 120, 750, 260);
        panel.setBackground(Color.BLACK);
        contentPane.add(panel);
        //new Color(220, 20, 60)

        b3 = new JButton("Issue");
        b3.addActionListener(this);
        b3.setBackground(Color.BLACK);
        b3.setForeground(Color.white);
        b3.setBounds(562, 620, 159, 41);
        contentPane.add(b3);
        b4 = new JButton("Return Book");
        b4.addActionListener(this);
        b4.setBackground(Color.BLACK);
        b4.setForeground(Color.white);
        b4.setBounds(76, 620, 143, 41);
        contentPane.add(b4);


        JLabel l5 = new JLabel("");
        l5.setBounds(60, 440, 159, 163);
        contentPane.add(l5);

        JLabel l6 = new JLabel("");
        l6.setBounds(332, 440, 139, 152);
        contentPane.add(l6);

        JLabel l7 = new JLabel("");
       
        l7.setBounds(562, 440, 157, 152);
        contentPane.add(l7);

        JPanel panel2 = new JPanel();
        panel2.setBorder(new TitledBorder(new LineBorder(new Color(205, 133, 63), 2), "Jos", TitledBorder.LEADING,
                TitledBorder.TOP, null, new Color(233, 150, 122)));
        panel2.setBounds(20, 420, 750, 270);
        panel2.setBackground(Color.BLACK);
        contentPane.add(panel2);

        getContentPane().setBackground(Color.BLACK);
        contentPane.setBackground(Color.white);
    }



    @Override
    public void actionPerformed(ActionEvent ae){
        
        
        if(ae.getSource() == b1){
            this.setVisible(false);
            new AddBook().setVisible(true);
        }
        if(ae.getSource() == b2){
            this.setVisible(false);
            new Member().setVisible(true);
        }
        if(ae.getSource() == b3){
            this.setVisible(false);
            new IssueBook().setVisible(true);
        }
        if(ae.getSource() == b4){
            this.setVisible(false);
            new returnBook().setVisible(true);
        }
       

    }
}