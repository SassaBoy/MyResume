/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sassa;

/**
 *
 * @author pc
 */

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class Log extends JFrame implements ActionListener{

    private final JPanel panel;
    private final JTextField textField;
    private final JPasswordField passwordField;
    private final JButton b1;
    private final JButton b2;


    public Log() {
        super("Login/Create");

        //Color class --> Swing
        //background --> Jframe
        setBackground(Color.black);
        setBounds(600, 300, 600, 400);

        panel = new JPanel();
        panel.setBackground(Color.black);
        setContentPane(panel);
        panel.setLayout(null);

        
        JLabel l1 = new JLabel("Name: ");
        l1.setBounds(124, 89, 95, 24);
        l1.setForeground(Color.white);
        panel.add(l1);

        JLabel l2 = new JLabel("Password: ");
        l2.setBounds(124, 124, 95, 24);
        l2.setForeground(Color.white);
        panel.add(l2);

        textField = new JTextField();
        textField.setBounds(210, 93, 157, 20);
        panel.add(textField);

        passwordField = new JPasswordField();
        passwordField.setBounds(210, 128, 157, 20);
        panel.add(passwordField);

        JLabel l3 = new JLabel("");
        l3.setBounds(377, 79, 46, 34);
        panel.add(l3);

        JLabel l4 = new JLabel("");
        l4.setBounds(377, 124, 46, 34);
        panel.add(l3);

        b1 = new JButton("Login");
        b1.addActionListener(this);

        b1.setForeground(Color.white);
        b1.setBackground(Color.black);
        b1.setBounds(149, 181, 113, 39);
        panel.add(b1);

        b2 = new JButton("Create");
        b2.addActionListener(this);

        b2.setForeground(Color.white);
        b2.setBackground(Color.black);
        b2.setBounds(289, 181, 113, 39);
        panel.add(b2);




//		JPanel panel2 = new JPanel();
//		panel2.setBackground(Color.YELLOW);
//		panel2.setBounds(24, 40, 434, 263);
//		panel.add(panel2);
    
    }

    @Override
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == b1){
            boolean status = false;
            try {
                Connection1 con = new Connection1();
                String sql = "select * from details where username=? and pass=?";
                PreparedStatement st = con.c.prepareStatement(sql);

                st.setString(1, textField.getText());
                st.setString(2, passwordField.getText());

                ResultSet rs = st.executeQuery();
                if (rs.next()) {
                    this.setVisible(false);
                    new homePage().setVisible(true);
                } else
                    JOptionPane.showMessageDialog(null, "Incorrect Username or password.");

            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
        if(ae.getSource() == b2){
            setVisible(false);
            Member su = new Member();
            su.setVisible(true);
        }
      
    }

    public static void main(String[] args) {
        new Log().setVisible(true);
    }

}