/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sassa.Users;

/**
 *
 * @author pc
 */
public class Book {
    //this is the concept of encapsulation
    private String Book_name;
    private String Publisher;
    private String Author;
    private int Pages;

    public Book(String Book_name, String Publisher, String Author, int Pages) {
        this.Book_name = Book_name;
        this.Publisher = Publisher;
        this.Author = Author;
        this.Pages = Pages;
    }

    public String getBook_name() {
        return Book_name;
    }

    public void setBook_name(String Book_name) {
        this.Book_name = Book_name;
    }

    public String getPublisher() {
        return Publisher;
    }

    public void setPublisher(String Publisher) {
        this.Publisher = Publisher;
    }

    public String getAuthor() {
        return Author;
    }

    public void setAuthor(String Author) {
        this.Author = Author;
    }

    public int getPages() {
        return Pages;
    }

    public void setPages(int Pages) {
        this.Pages = Pages;
    }

    @Override
    public String toString() {
        return "Book{" + "Book_name=" + Book_name + ", Publisher=" + Publisher + ", Author=" + Author + ", Pages=" + Pages + '}';
    }
    
        
    
}
