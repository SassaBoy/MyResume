/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sassa.Users;

/**
 *
 * @author pc
 */
public abstract class Student {
    public int student_id;
    public String name;
    public String father;
    public String course;
    public int year;
    public String semester;

    public Student(int student_id, String name, String father, String course, int year, String semester) {
        this.student_id = student_id;
        this.name = name;
        this.father = father;
        this.course = course;
        this.year = year;
        this.semester = semester;
    }

    public int getStudent_id() {
        return student_id;
    }

    public void setStudent_id(int student_id) {
        this.student_id = student_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFather() {
        return father;
    }

    public void setFather(String father) {
        this.father = father;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getSemester() {
        return semester;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }

    @Override
    public String toString() {
        return "Student{" + "student_id=" + student_id + ", name=" + name + ", father=" + father + ", course=" + course + ", year=" + year + ", semester=" + semester + '}';
    }
    
    
    
}
