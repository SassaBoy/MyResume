/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sassa.Users;

/**
 *
 * @author pc
 */

//This is a generic class
public class LogIn<Wola1, Wola2> {
    Object Wola1;
    Object Wola2;

    public LogIn(Object Wola1, Object Wola2) {
        this.Wola1 = Wola1;
        this.Wola2 = Wola2;
    }

    public Object getWola1() {
        return Wola1;
    }

    public void setWola1(Object Wola1) {
        this.Wola1 = Wola1;
    }

    public Object getWola2() {
        return Wola2;
    }

    public void setWola2(Object Wola2) {
        this.Wola2 = Wola2;
    }

    @Override
    public String toString() {
        return "LogIn{" + "Wola1=" + Wola1 + ", Wola2=" + Wola2 + '}';
    }
    
}
