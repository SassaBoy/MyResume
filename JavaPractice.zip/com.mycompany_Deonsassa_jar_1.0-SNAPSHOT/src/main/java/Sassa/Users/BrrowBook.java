/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sassa.Users;

/**
 *
 * @author pc
 */
public class BrrowBook {
    public int book_id;
    public int student_id;
    public String bname;
    public String sname;
    public String course;
    public String branch;

    public BrrowBook(int book_id, int student_id, String bname, String sname, String course, String branch) {
        this.book_id = book_id;
        this.student_id = student_id;
        this.bname = bname;
        this.sname = sname;
        this.course = course;
        this.branch = branch;
    }

    public int getBook_id() {
        return book_id;
    }

    public void setBook_id(int book_id) {
        this.book_id = book_id;
    }

    public int getStudent_id() {
        return student_id;
    }

    public void setStudent_id(int student_id) {
        this.student_id = student_id;
    }

    public String getBname() {
        return bname;
    }

    public void setBname(String bname) {
        this.bname = bname;
    }

    public String getSname() {
        return sname;
    }

    public void setSname(String sname) {
        this.sname = sname;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    @Override
    public String toString() {
        return "BrrowBook{" + "book_id=" + book_id + ", student_id=" + student_id + ", bname=" + bname + ", sname=" + sname + ", course=" + course + ", branch=" + branch + '}';
    }
    
}
