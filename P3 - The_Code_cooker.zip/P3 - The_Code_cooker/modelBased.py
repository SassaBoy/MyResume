
'''The algorithm below is a model-based reinforcement learning algorithm for the Pacman game applied to the AI:MA textbook's Gridworld, a simulated crawling robot. 
The algorithm uses a Q-function to learn the optimal policy for the game. The algorithm takes in the environment, hyperparameters, and the number of episodes to train the agent on 
which is now pacman in our case. It then outputs the Q-values matrix and rewards array for the agent over the time period. 
The algorithm is based on the Q-learning algorithm, which updates the Q-values matrix based on the reward received for taking a certain 
The Q-values matrix is used to determine the optimal policy for the agent, which 
is the sequence of actions that maximizes the expected reward.'''

# import necessary libraries
import numpy as np 
import random
import matplotlib.pyplot as plt

# Setting up our environment is the first step and we are calling it PacmanWorld
class PacmanWorld:
    def __init__(self, environmentsize, theGammaValue):
        #Initialize the variables
        self.environmentsize = environmentsize
        self.theGammaValue = theGammaValue
        #Here i am multiplying by two because i want a whole number
        #The state space indicates the space in which pacman can move in and it will be whatever the size is multiplied by two
        self.state_space = [x for x in range(self.environmentsize**2)]
        #This defines the actions that pacman can take
        self.possibleActions = ['up', 'down', 'left', 'right']
        #Reset the game
        self.reset()
        
    #The function to reset the game
    def reset(self):
        self.state = self.environmentsize**2 - 1
        #Terminals are the nodes all the way down which have utilities on them
        self.terminals = [0, self.environmentsize**2 - 1]
        return self.state
    #When the game begins, we will need to check for certain conditions such as which action pacman takes and handle the action accordingly
    def begin(self, action):
        reward = 0
        #The game runs until isOver is set to true
        isOver = False
        #This rewards are the ones that are going to determine the actions that pacman needs to take to obtain a better reward
        if action == 'up':
            #This says that if the agent moves up, and the result of the subtraction of the envoronment size from the state then the agent will be rewarded -1
            if self.state - self.environmentsize < 0:
                reward = -1
                self.state = self.state
            else:
                #Otherwize, just set the state of the agent minus the size of the environment
                self.state = self.state - self.environmentsize
                #This says that if the agent moves down, and the result of the addition of the envoronment size to the state is more then two times the environment size,
                # then the agent will be rewarded -1
        elif action == 'down':
            if self.state + self.environmentsize >= self.environmentsize**2:
                reward = -1
                self.state = self.state
            else:
                self.state = self.state + self.environmentsize
                #This says that if the agent moves to the right, and the result of the addition of 1 to the state is more than or equal to two times the environment size or the state modulus
                #the environment size is equal to the environment size - 1, then the reward is -1
                # then the agent will be rewarded -1
        elif action == 'right':
            if self.state + 1 >= self.environmentsize**2 or self.state % self.environmentsize == self.environmentsize-1:
                reward = -1
                self.state = self.state
            else:
                self.state = self.state + 1
        elif action == 'left':
            if self.state - 1 < 0 or self.state % self.environmentsize == 0:
                reward = -1
                self.state = self.state
            else:
                self.state = self.state - 1
        if self.state in self.terminals:
            isOver = True
            #The whole function then returns to us the state of the agent pacman, his rewards and sets the game to be over.
        return self.state, reward, isOver

# Here we are creating our q function that is responsible for generating our q values matrix and the rewards obtained over time
#Here the by the number of episodes i mean
'''Here we can plot the rewards array returned by the q_function() method.  
This should print an increasing trend if it's working properly and the Q-values matrix should contain values that reflect 
the expected reward of taking a certain action in a given state.'''


def q_function(theEnvironment, epsilon, alphaValue, theGammaValue, theNumberOfEpisodes):
    values = np.zeros((theEnvironment.environmentsize**2, len(theEnvironment.possibleActions)))
    #Creating an empty list to store the rewards over time 
    theRewardsOverTime = []
    #Here we loop through to the number of episodes or which is what we are using to train our pacman on
    for episode in range(theNumberOfEpisodes):
       
        # choose an action randomly
        state = theEnvironment.reset()
        isOver = False
        #While the game is stil running, generate a numpy random number and test it
        while not isOver:
            #If the random number genrated is less than epsilon
            if np.random.random() < epsilon:
                #the random integer number chosen is between 0 and the possible actions in the environment and set it to become the ction being taken by pacman
                action = np.random.randint(0, len(theEnvironment.possibleActions))
            else:
              action = np.argmax(values[state])
              #pacman's new state will be this if the first condition is not met
            next_state, reward, isOver = theEnvironment.begin(theEnvironment.possibleActions[action])
            values[state, action] = values[state, action] + alphaValue*(reward + theGammaValue*np.max(values[next_state]) - values[state, action])
            state = next_state
    theRewardsOverTime.append(reward)
    #Return the values and the rewards over time
    return values, theRewardsOverTime

# defining our main function which is going to run our game by passing in the environment defined above, 
# the learning rate or alpha, the gamma value and the number of episodes to train our data on.
def main(theEnvironment, epsilon, alphaValue, theGammaValue, theNumberOfEpisodes):
    values, theRewardsOverTime  = q_function(theEnvironment, epsilon, alphaValue, theGammaValue, theNumberOfEpisodes)
    #Let's plot our results with pyplot

   # plt.plot(theRewardsOverTime)
    #Title of our plot
    #plt.title("Rewards Obtained over the time period")
    #Show the diagram
    #plt.show()
    #This prints out a matrix of the q-values
    print(values)

# set up the environment and pass in the environment size and gamma

theEnvironment = PacmanWorld(4, 0.9)

# set hyperparameters
epsilon = 0.1
#This is the learning rate
alphaValue = 0.2
theGammaValue = 0.9
#This is what wse use to train our data on
theNumberOfEpisodes = 500

# calling our main function is easy, this is all we do by passing in our values
main(theEnvironment, epsilon, alphaValue, theGammaValue, theNumberOfEpisodes)
