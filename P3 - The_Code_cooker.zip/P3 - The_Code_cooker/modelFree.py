# Import Libraries 
#numpy is for the mathematic we will need
import numpy as np 
#This genrates a random number integer
import random 
#We will need a dictionary collection for our q values
from collections import defaultdict 

# Gridworld 

'''
This algorithm is implementing a reinforcement learning technique called Q-learning. 
It is used to teach an agent (in this case, pacman) how to navigate a gridworld to reach a goal.

'''
sizeOfGrid = 10  

# Rewards 
highestReward = 1 
lowestReward = 0 

# Triggers 
goalTrigger = 1 
hinderTrigger = 0 


# Actions 
up = 0 
down = 1 
left = 2 
right = 3

# Initialize Q-Table 
QTable = defaultdict(lambda: np.zeros(4)) 

# Our rewards table comes from numpy 
rewardTable = np.zeros((sizeOfGrid, sizeOfGrid)) 


# Set Reward Values 
for x in range(sizeOfGrid): 
    for y in range(sizeOfGrid): 
        if (x == 0 and y == 0): 
            rewardTable[x][y] = highestReward 
        else: 
            rewardTable[x][y] = lowestReward 

# Set Goal State 
rewardTable[0][0]


# Set Learning Parameters 
# If the value is close to 1, then future rewards are given more weight, while if it is close to 0, then only immediate rewards are considered.
gammaValue = 0.8 
#It is a value between 0 and 1 that determines the probability of choosing a random action.
# If the value is close to 1, then the algorithm will explore more, while if it is close to 0, the algorithm will focus more on exploiting the current knowledge.
epsilonValue = 0.2 
alphaValue = 0.8 


# Initialize Current State of pacman
state = np.random.randint(sizeOfGrid, size=(2)) 

# Initialize Time Step 
timeStep = 0 

# Repeat (for each episode)
# The episode is what we are training the pacman on 
# The algorithm iterates through episodes, updating the Q-Table as it learns.
while timeStep < 1000: 
    # Choose Action 
    # This is done to ensure that the algorithm explores the different actions in the environment and does not get stuck in a local optimum.
    if random.uniform(0, 1) < epsilonValue: 
        action = np.random.randint(4) 
    else: 
        '''
        The np.argmax() function finds the index of the maximum value in the array. 
        In this case, the array is the Q-Table for the current state, which is passed in as a tuple. 
        '''
        action = np.argmax(QTable[tuple(state)])
     
    # This line of code updates the current state of Pacman.
    new_state = (state[0] + (action == up) - (action == down), 
                 state[1] + (action == right) - (action == left)) 
    
    # Here we are
    #If so, then the reward is going to be the maximum reward
    # This ensures that if pacman reaches the goal state, it will be rewarded with the highest reward possible.
     
    if rewardTable[new_state] == goalTrigger: 
        reward = highestReward 
        #This means we haven't reached the goal and pacman need to continue
    elif rewardTable[new_state] == hinderTrigger: 
        continue
    else: 
        reward = lowestReward 
    
    # Update our Q-Table 
    # The Q-value for the state-action pair is calculated using the formula: Q(s,a) = (1-α)*Q(s,a) + α*(R + γ*maxQ(s',a')).
    QTable[state][action] = (1 - alphaValue) * QTable[state][action] + alphaValue * (reward + gammaValue * np.max(QTable[new_state])) 
    
    # Update State 
    state = new_state 
    
    # Update the Time Step 
    #This is used to keep track of the number of iterations the algorithm has gone through.
    timeStep = timeStep + 1 

# Print Q-Table 
print(QTable)