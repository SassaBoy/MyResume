/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.oop.studentController;

import com.example.oop.student.BookN;
import java.util.List;

    
interface BookInterface 
{
    
    public void save(BookN books);
    public void update(BookN books);
    public void delete(BookN book);
    public BookN get(int id);
    public List<BookN> list();

}
    

