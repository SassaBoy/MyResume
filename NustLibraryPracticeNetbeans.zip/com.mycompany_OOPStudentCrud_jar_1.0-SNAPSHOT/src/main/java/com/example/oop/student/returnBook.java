/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.oop.student;

import java.sql.Date;

/**
 *
 * @author pc
 */
public class returnBook extends issueBook{
    public Date dateOfReturn;

    public returnBook(String Book_Name, String Subject, String studentNumber, String studentName, java.sql.Date Date, Date dateOfReturn) {
        super(Book_Name, Subject, studentNumber, studentName, Date);
        this.dateOfReturn =  dateOfReturn;
    }
    public Date getdateOfReturn()
    {
        return dateOfReturn;
    }
    
    @Override
    public void setDate(Date date)
    {
        this.dateOfReturn = date;
    }
    @Override
    public String getBook_Name() {
        return Book_Name;
    }

    @Override
    public void setBook_Name(String Book_Name) {
        this.Book_Name = Book_Name;
    }

    @Override
    public String getSubject() {
        return Subject;
    }

    @Override
    public void setSubject(String Subject) {
        this.Subject = Subject;
    }

    @Override
    public String getStudentNumber() {
        return studentNumber;
    }

    @Override
    public void setStudentNumber(String studentNumber) {
        this.studentNumber = studentNumber;
    }

    @Override
    public String getStudentName() {
        return studentName;
    }

    @Override
    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    @Override
    public java.sql.Date getDate() {
        return Date;
    }

    public void setdate(java.sql.Date Date) {
        this.Date = Date;
    }
    
    
}
