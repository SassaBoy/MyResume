/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.oop.studentview;

/**
 *
 * @author pc
 */

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import static java.awt.image.ImageObserver.ABORT;

public class Home extends JFrame implements ActionListener{

    private final JPanel contentPane;
    private final JButton b1;
    private final JButton b2;
    private final JButton b3;
    private final JButton b4;
  

    public static void main(String[] args) {
        new Home().setVisible(true);
    }

    public Home() {
        super("NUST Library System");
        setBounds(400, 150, 1000, 800);
        contentPane = new JPanel();
        setContentPane(contentPane);
        contentPane.setLayout(null);


        JMenuBar menuBar = new JMenuBar();
        menuBar.add(Box.createRigidArea(new Dimension(400,100)));
        menuBar.setBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(0, 128, 0), new Color(128, 128, 128)));
        menuBar.setBackground(Color.black);
        menuBar.setBounds(0, 10, 1000, 40);
        contentPane.add(menuBar);

        JMenu mnExit = new JMenu("Exit");
        mnExit.setFont(new Font("Trebuchet MS", Font.BOLD, 17));


        JMenuItem mntmLogout = new JMenuItem("Logout");
        mntmLogout.setBackground(Color.white);
        mntmLogout.setForeground(Color.white);
        mntmLogout.addActionListener(this);
        mnExit.add(mntmLogout);

        JMenuItem mntmExit = new JMenuItem("Exit");
        mntmExit.setForeground(Color.black);
        mntmExit.setBackground(Color.black);
        mntmExit.addActionListener(this);
        mnExit.add(mntmExit);

        JMenu mnRecord = new JMenu("More Info");
        mnRecord.setFont(new Font("Trebuchet MS", Font.BOLD, 17));


        JMenuItem bookdetails = new JMenuItem("Book Details");
        bookdetails.addActionListener(this);
        bookdetails.setBackground(Color.white);
        bookdetails.setForeground(Color.black);
        mnRecord.add(bookdetails);

        JMenuItem studentdetails = new JMenuItem("Student Details");
        studentdetails.setBackground(Color.white);
        studentdetails.setForeground(Color.black);
        studentdetails.addActionListener(this);
        mnRecord.add(studentdetails);

        menuBar.add(mnRecord);
        menuBar.add(mnExit);


        JLabel l1 = new JLabel("Library Management System ");
        l1.setForeground(new Color(204, 51, 102));
        l1.setFont(new Font("Segoe UI Semilight", Font.BOLD, 30));
        l1.setBounds(268, 30, 701, 80);
        contentPane.add(l1);

        JLabel l3 = new JLabel("");
        l3.setBounds(300, 160, 134, 128);
        contentPane.add(l3);

        JLabel l4 = new JLabel("");
        l4.setBounds(530, 140, 225, 152);
        contentPane.add(l4);

        b1 = new JButton("Add Books");
        b1.addActionListener(this);
        b1.setBackground(Color.white);
        b1.setForeground(Color.black);
        b1.setBounds(60, 320, 159, 44);
        contentPane.add(b1);

        b2 = new JButton("Add Student");
        b2.addActionListener(this);
        b2.setBackground(Color.white);
        b2.setForeground(Color.black);
        b2.setBounds(562, 320, 167, 44);
        contentPane.add(b2);

        JPanel panel = new JPanel();
        panel.setBorder(new TitledBorder(new LineBorder(new Color(250, 128, 114), 2), "", TitledBorder.LEADING,
                TitledBorder.TOP, null, new Color(220, 20, 60)));
        panel.setBounds(20, 120, 750, 260);
        panel.setBackground(Color.black);
        contentPane.add(panel);

        b3 = new JButton("Issue Book");
        b3.addActionListener(this);
        b3.setBackground(Color.white);
        b3.setForeground(Color.black);
        b3.setBounds(562, 620, 159, 41);
        contentPane.add(b3);
        b4 = new JButton("Return Book");
        b4.addActionListener(this);
        b4.setBackground(Color.white);
        b4.setForeground(Color.black);
        b4.setBounds(76, 620, 143, 41);
        contentPane.add(b4);


        JLabel l5 = new JLabel("");
        l5.setBounds(60, 440, 159, 163);
        contentPane.add(l5);

        JLabel l6 = new JLabel("");
        l6.setBounds(332, 440, 139, 152);
        contentPane.add(l6);

        JLabel l7 = new JLabel("");
       
        l7.setBounds(562, 440, 157, 152);
        contentPane.add(l7);

        JPanel panel2 = new JPanel();
        panel2.setBorder(new TitledBorder(new LineBorder(new Color(205, 133, 63), 2), "", TitledBorder.LEADING,
                TitledBorder.TOP, null, new Color(233, 150, 122)));
        panel2.setBounds(20, 420, 750, 270);
        panel2.setBackground(Color.black);
        contentPane.add(panel2);

        getContentPane().setBackground(Color.BLUE);
        contentPane.setBackground(Color.WHITE);
    }



    @Override
    public void actionPerformed(ActionEvent e){
        String msg = e.getActionCommand();
        if(msg.equals("Logout")){
            setVisible(false);
            new Login().setVisible(true);
        }else if(msg.equals("Exit")){
            System.exit(ABORT);
        }

        if(e.getSource() == b1){
            this.setVisible(false);
            new Book().setVisible(true);
        }
        if(e.getSource() == b2){
            this.setVisible(false);
            new StudentForm().setVisible(true);
        }
        if(e.getSource() == b3){
            this.setVisible(false);
            new issueBook().setVisible(true);
        }
        if(e.getSource() == b4){
           this.setVisible(false);
           // new ReturnBook2().setVisible(true);
        }
        
       

    }
}