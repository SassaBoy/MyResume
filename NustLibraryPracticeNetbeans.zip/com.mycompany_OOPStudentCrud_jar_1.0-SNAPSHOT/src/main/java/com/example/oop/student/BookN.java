/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.oop.student;

/**
 *
 * @author pc
 */
public class BookN {
    public int book_ID;
    public String bookName;
    public String Book_Edition;
    public String Subject;
    public int year;

    public int getBook_ID() {
        return book_ID;
    }

    public void setBook_ID(int book_ID) {
        this.book_ID = book_ID;
    }

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public String getBook_Edition() {
        return Book_Edition;
    }

    public void setBook_Edition(String Book_Edition) {
        this.Book_Edition = Book_Edition;
    }

    public String getSubject() {
        return Subject;
    }

    public void setSubject(String Subject) {
        this.Subject = Subject;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    @Override
    public String toString() {
        return "Book{" + "book_ID=" + book_ID + ", bookName=" + bookName + ", Book_Edition=" + Book_Edition + ", Subject=" + Subject + ", year=" + year + '}';
    }
    
    
    
}
