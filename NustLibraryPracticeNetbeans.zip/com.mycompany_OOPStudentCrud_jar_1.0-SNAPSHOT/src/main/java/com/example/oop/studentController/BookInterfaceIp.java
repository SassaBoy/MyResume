/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.oop.studentController;

import com.example.oop.student.BookN;
import com.example.oop.studentdb.StudentDb;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
//implementing the Book interface


public class BookInterfaceIp implements BookInterface {

    @Override
    public void save(BookN books) {

         try {
            Connection con =  StudentDb.getConnection();
            String sql  = "INSERT INTO book(id,Book_name,Book_Edition,Subject, Year) VALUES (?,?,?,?,?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, books.getBook_ID());
            ps.setString(2, books.getBookName());
            ps.setString(3, books.getBook_Edition());
            ps.setString(4, books.getSubject());
            ps.setInt(5, books.getYear());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Saved!");
        } catch (Exception e) {
             JOptionPane.showMessageDialog(null, "Error");
        }
    }

    @Override
    public void update(BookN books) {
       
        
         try {
           
            Connection con = StudentDb.getConnection();
            String sql = "UPDATE book SET Book_name=?,Book_Edition=?,Subject=?, Year=? WHERE id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, books.getBook_ID());
            ps.setString(2, books.getBookName());
            ps.setString(3, books.getBook_Edition());
            ps.setString(4, books.getSubject());
            ps.setInt(5, books.getYear());
            ps.executeUpdate();

        
            JOptionPane.showMessageDialog(null, "Updated!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error");
        }
        
    }

    @Override
    public void delete(BookN book) {
       try {
           
            Connection con = StudentDb.getConnection();
            String sql = "delete from book  WHERE id=?";
            PreparedStatement ps = con.prepareStatement(sql);  
            ps.setInt(1, book.getBook_ID());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Deleted!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error");
        }
    }

    @Override
    public BookN get(int id) {
        
        
         BookN st = new BookN();
        try {
            Connection con = StudentDb.getConnection();
            String sql = "SELECT * FROM book WHERE id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                
                 st.setBook_ID(rs.getInt("id"));
                st.setBookName(rs.getString("bookName"));
                st.setBook_Edition(rs.getString("Book_Edition"));
                st.setSubject(rs.getString("Subject"));
                st.setYear(rs.getInt("Year"));
    

            }
            
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error");
        }
        return st;
    }

    @Override
    public List<BookN> list() {
      
          List<BookN> list = new ArrayList<>();
        try {
            Connection con = StudentDb.getConnection();
            String sql = "SELECT * FROM book";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            
            
                 BookN st = new BookN();
            while(rs.next()){
               
                st.setBook_ID(rs.getInt("id"));
                st.setBookName(rs.getString("Book_Name"));
                st.setBook_Edition(rs.getString("Book_Edition"));
                st.setSubject(rs.getString("Subject"));
                st.setYear(rs.getInt("Year"));
               
                list.add(st);
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error");
        }
        return list;
  
    }

 
    
}
