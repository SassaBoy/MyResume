/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.oop.student;

import java.sql.Date;


public class issueBook {
    public String Book_Name;
    public String Subject;
    public String studentNumber;
   public String studentName;
    public Date Date;

    public issueBook(String Book_Name, String Subject, String studentNumber, String studentName, Date Date) {
        this.Book_Name = Book_Name;
        this.Subject = Subject;
        this.studentNumber = studentNumber;
        this.studentName = studentName;
        this.Date = Date;
    }

    public String getBook_Name() {
        return Book_Name;
    }

    public void setBook_Name(String Book_Name) {
        this.Book_Name = Book_Name;
    }

    public String getSubject() {
        return Subject;
    }

    public void setSubject(String Subject) {
        this.Subject = Subject;
    }

    public String getStudentNumber() {
        return studentNumber;
    }

    public void setStudentNumber(String studentNumber) {
        this.studentNumber = studentNumber;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public Date getDate() {
        return Date;
    }

    public void setDate(Date Date) {
        this.Date = Date;
    }

    @Override
    public String toString() {
        return "issueBook{" + "Book_Name=" + Book_Name + ", Subject=" + Subject + ", studentNumber=" + studentNumber + ", studentName=" + studentName + ", Date=" + Date + '}';
    }
    
    
}
