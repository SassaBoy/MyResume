/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.oop.student;

/**
 *
 * @author pc
 */
//this is a generics class 

public class LogIn<U1, U2>{

    
    //defining the Objects and not specifying that it's a String or Integer
    Object U1;
    Object U2;

    public LogIn(Object U1, Object U2) {
        this.U1 = U1;
        this.U2 = U2;
    }

    public Object getU1() {
        return U1;
    }

    public void setU1(Object U1) {
        this.U1 = U1;
    }

    public Object getU2() {
        return U2;
    }

    public void setU2(Object U2) {
        this.U2 = U2;
    }

    @Override
    public String toString() {
        return "LogIn{" + "U1=" + U1 + ", U2=" + U2 + '}';
    }
    
    
    
    
}
