/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.oop.studentController;

import com.example.oop.student.Student;
import com.example.oop.studentdb.StudentDb;
 import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;


public class StudentDAOImp implements StudentDAO {

    @Override
    public void save(Student students) {

         try {
            Connection con =  StudentDb.getConnection();
            String sql = "INSERT INTO student(id,fname,Course,fee) VALUES (?,?,?,?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, students.getId());
            ps.setString(2, students.getFname());
            ps.setString(3, students.getCourse());
            ps.setInt(4, students.getFee());
            if(students.getFee() < 1){
                JOptionPane.showMessageDialog(null, "Not full payment. Minimum is $1");
            }else{
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Saved!");
        }
         }catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error");
        }
    }

    @Override
    public void update(Student students) {
       
        
         try {
           
            Connection con = StudentDb.getConnection();
            String sql = "UPDATE student SET fname=?,Course=?,fee=? WHERE id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, students.getFname());
            ps.setString(2, students.getCourse());
            ps.setInt(3, students.getFee());
            ps.setInt(4, students.getId());
            ps.executeUpdate();

        
            JOptionPane.showMessageDialog(null, "Updated!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error");
        }
        
    }

    @Override
    public void delete(Student students) {
       try {
           
            Connection con = StudentDb.getConnection();
            String sql = "delete from student  WHERE id=?";
            PreparedStatement ps = con.prepareStatement(sql);  
            ps.setInt(1, students.getId());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Deleted!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error");
        }
    }

    @Override
    public Student get(int id) {
        
        
         Student st = new Student();
        try {
            Connection con = StudentDb.getConnection();
            String sql = "SELECT * FROM student WHERE id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                
                 st.setId(rs.getInt("id"));
                st.setFname(rs.getString("fname"));
                st.setCourse(rs.getString("course"));
                st.setFee(rs.getInt("fee"));

            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error");
        }
        return st;
    }

    @Override
    public List<Student> list() {
      
          List<Student> list = new ArrayList<>();
        try {
            Connection con = StudentDb.getConnection();
            String sql = "SELECT * FROM student ";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            
            
            
            while(rs.next()){
                Student st = new Student();
                st.setId(rs.getInt("id"));
                st.setFname(rs.getString("fname"));
                st.setCourse(rs.getString("Course"));
                st.setFee(rs.getInt("fee"));

                list.add(st);
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error");
        }
        return list;
  
    }
    
}

