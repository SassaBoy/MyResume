#This imports the module containing several functions for the data structures manipulation so that we do not have to recode but just call the functions
import myFunctions

#This class contains a variety of searching algorithms and we will use the class' algorithms to pass in data in other modules of our choice
class SeachingAlgorithms:
    #Here we initialize the class so that we can call our class in other modules
    def __init__(self, values):
        self.values = values
        
    def getNextNode(self, state):
        return self.values[state]

#This is a searching algorithm that explores the shallowest nodes first

    def bfs(values, startNode1, goal):
    #It uses a queue because this specific data structure uses what we call a FIFO structure meaning it explores the first node in front of the queue
         MyQueue = myFunctions.Queue()
    #To store the  expanded nodes
         expanded = []
    #only start exploring if the provided start state is in the list provided
         if(startNode1 in values):
            startState = startNode1
            start = (startState, [], 0) 
    
         MyQueue.push(start)
    
         while not MyQueue.isEmpty():
           currentState, actions, currentCost = MyQueue.pop()
        
           if currentState not in expanded:
            expanded.append(currentState)

            if currentState == goal:
              return actions
        
            else:
                #get the nodes following the node
                suc = values.getNextNode(currentState)
                
                for successorState, succAction, succCost in suc:
                    newAction = actions + [succAction]
                    newCost = currentCost + succCost
                    newNode = (successorState, newAction, newCost)

                    MyQueue.push(newNode)
         return actions

    def dfs(values, startNode1, goal):
    #Here we use a stack since the depth first algorithm uses a structure of last in first out
    #Meaning the last node in the stack will be the first to expand
       MyStack = myFunctions.Stack()
       expanded = []
    #get the start state
       if(startNode1 in values):
        startState = startNode1
      #The start state plus its empty list of sequences
        start = (startState, [])
      #Pus the starting node in the stack
        MyStack.push(start)
    
    #While the stack is not empty, start the search
       while not MyStack.isEmpty():
        currentState, actions = MyStack.pop()
        #To chek if we have not visited the node yet
        if currentState not in expanded:
            expanded.append(currentState)
            #Here we return a goal with its set of actions if we find it
            if currentState == goal:
                return actions
            else:
                #get the next node instead
                suc = values.getNextNode(currentState)
                for successorState, succAction, succCost in suc:
                    newAction = actions + [succAction]
                    newNode = (successorState, newAction)
                    MyStack.push(newNode)
 #Return all sets of actions taken to reach the goal state
        return actions  

#The uniform cost search algorithm's obligation is to expand the node that have the least cost so that it can reach the goal state very quickly
#It only uses the cost which is g(n) and ignore the heuristics
#I describe this algorithm as the A* search algorithm that doesn't use the heuristics

#This algorithm is optimal by nature and hence its name uniform means cheapest
#It takes in the values to be searched
    def ucs(values, startNode1, goal):
      #Here, I am using the queue because the uniform cost search uses a queue as its data structure
        PriorityQueue = myFunctions.PriorityQueue()

    #This is a list to store the expanded nodes so that when we reach a node that has already been expanded, we check if its cost is better than that of the expanded one, if so, update it
    #This will enable us to preclude the searching from entering a loop
        expanded = {}
    
        if(startNode1 in values):
          startState = startNode1
          start = (startState, [], 0) #(state, action, cost)
    
          PriorityQueue.push(start, 0)
        while not PriorityQueue.isEmpty():
         currentState, actions, currentCost = PriorityQueue.pop()
       
         if (currentState not in expanded) or (currentCost < expanded[currentState]):
            #put popped node's state into explored list
              expanded[currentState] = currentCost

              if currentState == goal:
                return actions
              else:
                #list of (successor, action, cost)
                suc = values.getNextNode(currentState)
                
                for successorState, succAction, succCost in suc:
                    newAction = actions + [succAction]
                    newCost = currentCost + succCost
                    newNode = (successorState, newAction, newCost)
                   #Update the queue if we find an already explore node with a lower cost
                    PriorityQueue.update(newNode, newCost)

        return actions
#A heuristc is the estimated cost from the start to the goal state, meaning how far a node is still to go to reach the goal state

def h(self, n):
        H = {
            'A': 1,
            'B': 1,
            'C': 1,
            'D': 1
        }

        return H[n]
       
def a_star(self, start_node, goal):
        # open_list is a list of nodes which have been visited, but who's neighbors
        # haven't all been inspected, starts off with the start node
        # closed_list is a list of nodes which have been visited
        # and who's neighbors have been inspected
           open = set([start_node])
           closed = set([])

        # g contains current distances from start_node to all other nodes
        # the default value (if it's not found in the map) is +infinity
           g = {}

           g[start_node] = 0

        # parents contains an adjacency map of all nodes
           parents = {}
           parents[start_node] = start_node

           while len(open) > 0:
            n = None

            # find a node with the lowest value of f() - evaluation function
            for v in open:
                if n == None or g[v] + self.h(v) < g[n] + self.h(n):
                    n = v

            if n == None:
                return None

            # if the current node is the stop_node
            # then we begin reconstructin the path from it to the start_node
            if n == goal:
                reconst_path = []

                while parents[n] != n:
                    reconst_path.append(n)
                    n = parents[n]

                reconst_path.append(start_node)

                reconst_path.reverse()

                print('Found: {}'.format(reconst_path))
                return reconst_path

            # for all neighbors of the current node do
            for (m, weight) in self.getNext(n):
                # if the current node isn't in both open_list and closed_list
                # add it to open_list and note n as it's parent
                if m not in open and m not in closed:
                    open.add(m)
                    parents[m] = n
                    g[m] = g[n] + weight

                # otherwise, check if it's quicker to first visit n, then m
                # and if it is, update parent data and g data
                # and if the node was in the closed_list, move it to open_list
                else:
                    if g[m] > g[n] + weight:
                        g[m] = g[n] + weight
                        parents[m] = n

                        if m in closed:
                            closed.remove(m)
                            open.add(m)

            # remove n from the open_list, and add it to closed_list
            # because all of his neighbors were inspected
            open.remove(n)
            closed.add(n)

      
            return None

