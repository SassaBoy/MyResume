
from search import SeachingAlgorithms


tree1 = {
    'A': [('B', 1), ('C', 3), ('D', 7)],
    'B': [('D', 5)],
    'C': [('D', 12)]
}


search1 = SeachingAlgorithms(tree1)
search1.a_star_algorithm('A', 'D')

