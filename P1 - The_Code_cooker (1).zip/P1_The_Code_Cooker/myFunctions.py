#This classes contain a list of functions which we are going to need when exploring our stat structures
#When we need a function, we just call it from here and this saves a lot of time for us

#Creating  a stack data structure for us
class Stack:
    def __init__(self):
        self.list = []

#Add items onto the top of the stack
    def push(self,item):
        self.list.append(item)
#Get the last node on top of the stack
    def pop(self):
        return self.list.pop()
     #Check if the stack is empty
    def isEmpty(self):
        return len(self.list) == 0

class Queue:
    #Initializing our queue data structure
    def __init__(self):
        self.list = []

    #Push here means to enqueue or add an item to the queue
    def push(self,item):
        self.list.insert(0,item)
    
    #As we saw in the stack, here we are dequeing from the queue
    def pop(self):

        return self.list.pop()
 #Similar to the stack
    def isEmpty(self):
        return len(self.list) == 0

class PriorityQueue:
# structure allows O(1) access to the lowest-priority item.
    def  __init__(self):
        self.heap = []
        self.count = 0

    def push(self, item, levelOfPrecedence):
        entry = (levelOfPrecedence, self.count, item)
        heapq.heappush(self.heap, entry)
        self.count += 1

    def pop(self):
        (_, _, item) = heapq.heappop(self.heap)
        return item

    def isEmpty(self):
        return len(self.heap) == 0
#Update our priority queue
    def update(self, node, levelOfPrecedence):
        for index, (p, d, i) in enumerate(self.heap):
            if i == node:
                if p <= levelOfPrecedence:
                    break
                del self.heap[index]
                self.heap.append((levelOfPrecedence, d, node))
                heapq.heapify(self.heap)
                break
        else:
            self.push(item, levelOfPrecedence)



